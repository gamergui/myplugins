# OpenOSRSnmz

Very basic NMZ automation in the OpenOSRS client. Drinks prayer potions when low and overload pots when full health.
